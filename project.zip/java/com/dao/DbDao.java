package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.model.CartModel;
import com.model.ContactModel;
import com.model.ProductModel;
import com.model.SignupModel;
import com.model.WishListModel;

public class DbDao 
{
	public static Connection getconnect()
	{
		Connection con = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jspproject1","root","");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	public static int savedata(SignupModel m)
	{
		int status =0;
		
		Connection con = DbDao.getconnect();
		
		try 
		{
			PreparedStatement ps =con.prepareStatement("insert into signup(name,email,mobile,password) values (?,?,?,?)");
			 ps.setString(1, m.getName());
			 ps.setString(2, m.getEmail());
			 ps.setString(3, m.getMobile());
			 ps.setString(4, m.getPassword());
	
			 status = ps.executeUpdate();
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
		public SignupModel LoginCustomer(SignupModel model) 
		{
			boolean flag = false;

			SignupModel obj = null;

			try {
				Connection con = DbDao.getconnect();
				PreparedStatement ps = con.prepareStatement("select * from signup where email=? and password=?");
				ps.setString(1, model.getEmail());
				ps.setString(2, model.getPassword());

				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					obj = new SignupModel();
					obj.setName(rs.getString("name"));
					obj.setEmail(rs.getString("email"));
					obj.setPassword(rs.getString("password"));

				}

			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return obj;
		}
		public static int contactinsert(ContactModel m)
		{
			int status =0;
			
			Connection con = DbDao.getconnect();
			
			try 
			{
				PreparedStatement ps =con.prepareStatement("insert into contact(name,email,message) values (?,?,?)");
				 ps.setString(1, m.getName());
				 ps.setString(2, m.getEmail());
				 ps.setString(3, m.getMessage());
				 
		
				 status = ps.executeUpdate();
			}
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return status;
		}
		
		public static List<ProductModel>productviewdata()
		{
			
			List<ProductModel>list = new ArrayList<ProductModel>();
			Connection con = DbDao.getconnect();
			try 
			{
				PreparedStatement ps =con.prepareStatement("Select * from products");
				ResultSet set = ps.executeQuery();
				while(set.next())
				{
					int id = set.getInt(1);
					String pname = set.getString(2);
					String pprice= set.getString(3);
					String pimage = set.getString(4);
					
					
					ProductModel m =new ProductModel();
					m.setId(id);
					m.setProduct_name(pname);
					m.setProduct_price(pprice);
					m.setProduct_image(pimage);
					list.add(m);
				}
				
			} 
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return list;
			
		}
		public static ProductModel getproductdetail(int id)
		{
			
			ProductModel m =new ProductModel();
			
				Connection con =DbDao.getconnect();
				
				try 
				{
					PreparedStatement ps =(PreparedStatement) con.prepareStatement("select * from products where id=?");
					ps.setInt(1,id);
					ResultSet set=ps.executeQuery();
					
					if(set.next())
					{
						
						m.setId(set.getInt(1));
						m.setProduct_name(set.getString(2));
						m.setProduct_price(set.getString(3));
						m.setProduct_image(set.getString(4));
						
						
					}
					
				} 
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
			return m;
			
		}

		public static int Wishadd(WishListModel m) {
			int status = 0;

			Connection con = DbDao.getconnect();

			try {
				PreparedStatement ps = con.prepareStatement("insert into wishlist(id,product_name,product_price,product_image,email) values(?,?,?,?,?)");

				ps.setInt(1, m.getId());
				ps.setString(2, m.getProduct_name());
				ps.setString(3, m.getProduct_price());
				ps.setString(4, m.getProduct_image());
				ps.setString(5, m.getEmail());
			

				status = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return status;
		}	
		
		public static List<WishListModel> getallwishdetail(SignupModel m2)
		{
			List<WishListModel> i2 = new ArrayList<WishListModel>();
			
			HttpServletRequest request = null;
			
			try {
				
				
				SignupModel s=new SignupModel();
				Connection con = DbDao.getconnect();
				PreparedStatement ps= con.prepareStatement("Select * from wishlist where email=? ");
				System.out.println(m2.getEmail());
				ps.setString(1, m2.getEmail());
				ResultSet rs = (ResultSet) ps.executeQuery();
				
				while(rs.next())
				{
					WishListModel d1 = new WishListModel();
					//d1 = new ImageModel();
					d1.setId(rs.getInt(1));
					d1.setProduct_name(rs.getString(2));
					d1.setProduct_price(rs.getString(3));
					d1.setProduct_image(rs.getString(4));
					d1.setEmail(rs.getString(5));
					i2.add(d1);
					
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			return i2;
		}
		
		public static int CartAdd(CartModel m) {
			int status = 0;

			Connection con = DbDao.getconnect();

			try {
				PreparedStatement ps = con.prepareStatement("insert into cart(myid,product_name,product_price,product_image,email) values(?,?,?,?,?)");

				ps.setInt(1, m.getId());
				ps.setString(2, m.getProduct_name());
				ps.setString(3, m.getProduct_price());
				ps.setString(4, m.getProduct_image());
				ps.setString(5, m.getEmail());
			

				status = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return status;
		}	
		
		
		public static List<WishListModel> getallcartdetail(SignupModel m2)
		{
			List<WishListModel> i2 = new ArrayList<WishListModel>();
			
			HttpServletRequest request = null;
			
			try {
				
				
				SignupModel s=new SignupModel();
				Connection con = DbDao.getconnect();
				PreparedStatement ps= con.prepareStatement("Select * from cart where email=? ");
				System.out.println(m2.getEmail());
				ps.setString(1, m2.getEmail());
				ResultSet rs = (ResultSet) ps.executeQuery();
				
				while(rs.next())
				{
					WishListModel d1 = new WishListModel();
					//d1 = new ImageModel();
					d1.setId(rs.getInt(1));
					d1.setProduct_name(rs.getString(2));
					d1.setProduct_price(rs.getString(3));
					d1.setProduct_image(rs.getString(4));
					d1.setEmail(rs.getString(5));
					i2.add(d1);
					
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			return i2;
		}
		
}

	
	

